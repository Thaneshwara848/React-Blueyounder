import './App.css';
// import Greet from './components/Greet';
import {Greet} from './components/Greet';
import Welcome  from './components/Welcome';
import Hello  from './components/Hello';
import Message from './components/Message';
import Counter from './components/Counter';


function App() {
  return (
    <div className="App">
    
     
      {/* <Greet  name="Arun" />
      <Greet name="Bharath" />
      <Greet name="Charan"/> */}

    {/* <Greet  name="Arun"  desig="Clerk" />
      <Greet name="Bharath" desig="Developer" />
      <Greet name="Charan" desig="Manager" />

      <Greet  name="Arun"  desig="Clerk" > 
        <p>This is a Childres Props </p>
      </Greet>
      <Greet name="Bharath" desig="Developer" >
        <button>Click </button>
      </Greet>
      <Greet name="Charan" desig="Manager" />
      
      <Welcome name="Arun"  desig="Clerk"></Welcome>
      <Welcome  name="Bharath" desig="Developer" ></Welcome>
      <Welcome name="Charan" desig="Manager"></Welcome> */}

      {/* <Message /> */}

      <Counter/>
    </div>
  );
}


export default App;
