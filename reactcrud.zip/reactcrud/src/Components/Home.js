function Home() {
    return (
        <div>
        {/* <h1 style={{textAlign:'center',fontSize:'50px'}}> Hi Welcome to React JS Application </h1>
        <h1>
          <a  href='/insert'> INSERT </a>||
          <a href='/display'> DISPALY </a>||
          <a href='/displaybyid'> DISPALYBYID  </a> || 
          <a  href='/update'> UDPDATE </a>||
          <a href='/delete'> DELETE </a>||
          <a href='/deletebyid'> DELETEBYID  </a>
        </h1>         */}
      </div>
    );
  }
  
  export default Home;
  