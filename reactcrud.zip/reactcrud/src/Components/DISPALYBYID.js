
function DISPLAYBYID() {
    return (
      <div>
        <h1 style={{textAlign:'center',fontSize:'50px'}}> Hi DISPLAYBYID   </h1>
        
      </div>
    );
  }
  
  export default DISPLAYBYID;
  