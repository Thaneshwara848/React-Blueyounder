import './App.css';
import DELETE from './Components/DELETE';
import DISPALY from './Components/DISPALY';
import DISPALYBYID from './Components/DISPALYBYID';
import INSERT from './Components/INSERT';
import UDPDATE from './Components/UDPDATE';
import DELETEBYID from './Components/DELETEBYID';
import Home from './Components/Home';
import {
  BrowserRouter as Router,
  Route,
  Routes,
} from 'react-router-dom';

function App() {
  return (
    <div>   
      <h1 style={{textAlign:'center',fontSize:'50px'}}> Hi Welcome to React JS Application </h1>
        <h1>
          <a  href='/insert'> INSERT </a>||
          <a href='/display'> DISPALY </a>||
          <a href='/displaybyid'> DISPALYBYID  </a> || 
          <a  href='/update'> UDPDATE </a>||
          <a href='/delete'> DELETE </a>||
          <a href='/deletebyid'> DELETEBYID  </a>
        </h1>  
        
      <Router>
        <Routes>
          {/* <Route path="" element={<Navigate to="/display" />} /> */}
          <Route path="/insert" element={<INSERT />} />
          <Route path="/display" element={<DISPALY/>} />
          <Route path="/displaybyid" element={<DISPALYBYID/>} />
          <Route path="/update" element={<UDPDATE/>} />
          <Route path="/delete" element={ <DELETE />} />
          <Route path="/deletebyid" element={<DELETEBYID/>} />
          <Route path="/" element={<Home/>} />
        </Routes>
      </Router>
      </div>
  );
}

export default App;
