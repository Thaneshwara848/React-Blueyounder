function DELETE() {
    return (
      <div>
        <h1 style={{textAlign:'center',fontSize:'50px'}}> Hi DELETE   </h1>
        
      </div>
    );
  }
  
  export default DELETE;
  