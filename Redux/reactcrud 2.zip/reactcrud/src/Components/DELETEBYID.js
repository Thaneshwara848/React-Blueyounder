import React, { useState } from 'react';
import axios from 'axios';


const DELETEBYID = () => {

  const [formData, setFormData] = useState({});
 // const [responseData, setResponseData] = useState({});


  const handleSignUp = async (e) => {
    e.preventDefault();
    console.log(e)

    let data = {
      id: e.target[0].value
    }

    setFormData(data)

    try {
      const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'DELETE',
        'Access-Control-Allow-Headers': 'Content-Type'
      };
      const response = await axios.delete(`http://localhost:9999/deleteProd/${e.target[0].value}`, { headers: headers });
        console.log(response)
        // if(response.status==200){
        //   alert("successfully Registered ....!")
        // }
        


        //setResponseData(response.data);// storing but never used : no use of stroing since its post  
    } catch (error) {
        console.error('Error fetching data:', error.message);
    }
  }

  return (

    <div className='card' style={{textAlign:'center'}}>
      <h1>
        ADD Product 
      </h1>
      <form onSubmit={handleSignUp}>
        <input
          name="id"
          type="text"
          value={formData.id}
          placeholder="Enter ID"
        />
        
        <div style={{ paddingTop: "8px" }}>
          <button
            type="submit"
            className="mt-4 h-12 w-full"
          >
           DELETE  Product 
          </button>
        </div>
      </form>
    </div>
  );
};

export default DELETEBYID;