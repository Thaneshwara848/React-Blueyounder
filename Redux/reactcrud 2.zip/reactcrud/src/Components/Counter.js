import React from 'react';
import { useSelector, useDispatch } from 'react-redux';

const MyComponent = () => {
  const counter = useSelector((state) => state.counter); // Adjust to your state structure
  const dispatch = useDispatch();
  console.log(counter)

  const increment = () => {
    dispatch({ type: 'INCREMENT' }); // Dispatch your action types
  };

  const decrement = () => {
    dispatch({ type: 'DECREMENT' }); // Dispatch your action types
  };

  return (
    <div>
      <button onClick={decrement}>Decrement</button>
      <p>Counter: {counter}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

export default MyComponent;
