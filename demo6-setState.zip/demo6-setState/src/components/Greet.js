import React from "react";

// function Greet(){
//     return <h1>HI Thanesh Good Morning </h1>
// }

// //can be replaced with the lamada FUnction // Fat arrwo function 
// export default Greet;

// const Greet = ()=><h1> HI Thanesh <br/> Demo Check With fat Arrow Funuction </h1>


// export const Greet = ()=><h1> HI Thanesh <br/> Demo Check With fat Arrow Funuction </h1>

// export const Greet = ()=><h1> HI Thanesh </h1>

// export const Greet = (props)=>{
//         console.log(props)
//  return <h1> HI {props.name} </h1>

// }

// export const Greet = (props)=>{
//     console.log(props)
// return <h1> HI {props.name} working as {props.desig} </h1>

// }

// export const Greet = (props)=>{
//     console.log(props)
//     // props.name="Thanesh"; in function we cant modify the data : immutable 
//     return (
//     <div>
//         <h1> HI {props.name} working as {props.desig} </h1>
//         {props.children}
//     </div>
//     )
// }




