import React from "react";


const Hello = ()=> {
 

    // return React.createElement('div',null,'<h1>','Hello Thanesh Demo JSX')
    
    // return React.createElement('div',null,React.createElement('h1',null,'Hello Thanesh'))
    return React.createElement(
        'div',
        {id:'hello',className:'Democheck'},
        React.createElement('h1',null,'Hello Thanesh'))
}

export default Hello;