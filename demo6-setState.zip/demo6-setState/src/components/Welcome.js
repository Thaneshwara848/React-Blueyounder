// Class COmponent  Demo 

import React, { Component }  from "react";

class Welcome extends Component
{
    // we have to use this keyword if we are  using this class to access the variables 
    render(){
        return <h1> Hi Welcome {this.props.name} working as {this.props.desig}</h1>
    }

}

export default Welcome;